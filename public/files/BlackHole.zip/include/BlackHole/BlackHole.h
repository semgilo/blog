//
//  BlackHole.h
//  BlackHole
//
//  Created by semgilo on 2018/11/24.
//  Copyright © 2018年 semgilo. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface BlackHole : NSObject
{
    
}

@property (strong, nonatomic) NSString *error;

+(BlackHole *) sharedInstance;

-(void)onStart:(NSString *)appID;

-(BOOL)checkErrors;

- (UIViewController* )showError:(NSString *)error;

@end
